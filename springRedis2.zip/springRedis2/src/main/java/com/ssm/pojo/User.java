package com.ssm.pojo;

import java.io.Serializable;

/**
 * @param user
 * @Author: lyx
 * @Date: 2018/7/6
 */
public class User implements Serializable {
    private int id;
    private String userName;
    private String sex;
    private int age;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    //lyx 2018.7.6
    public String toString() {
       return "user:"+ userName +", age:" + age + ", sex:" + sex;
    }
}
