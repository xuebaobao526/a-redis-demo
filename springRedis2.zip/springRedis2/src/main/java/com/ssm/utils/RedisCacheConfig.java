package com.ssm.utils;

import org.springframework.cache.annotation.CachingConfigurerSupport;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;

import java.lang.reflect.Method;

/**
 * @param user
 * @Author: lyx
 * @Date: 2018/7/5
 */
/*在配置类(@Configuration)上使用@EnableCaching注解时，会触发一个post processor，
这会扫描每一个spring bean，查看是否已经存在注解对应的缓存,
如果找到了，就会自动创建一个代理拦截方法调用，使用缓存的bean执行处理
 */
@Configuration
@EnableCaching
public class RedisCacheConfig extends CachingConfigurerSupport {

    private volatile JedisConnectionFactory jedisConnectionFactory;
    private volatile RedisTemplate<String, String> redisTemplate;
    private volatile RedisCacheManager redisCacheManager;

    public RedisCacheConfig() {
        super();
    }
    /**
     * 带参数的构造方法 初始化所有的成员变量
     *
     * @param jedisConnectionFactory
     * @param redisTemplate
     * @param redisCacheManager
     */
    public RedisCacheConfig(JedisConnectionFactory jedisConnectionFactory, RedisTemplate<String, String> redisTemplate,
                            RedisCacheManager redisCacheManager) {
        this.jedisConnectionFactory = jedisConnectionFactory;
        this.redisTemplate = redisTemplate;
        this.redisCacheManager = redisCacheManager;
    }

    //各变量的get方法
    public JedisConnectionFactory getJedisConnecionFactory() {
        return jedisConnectionFactory;
    }
    public RedisTemplate<String, String> getRedisTemplate() {
        return redisTemplate;
    }
    public RedisCacheManager getRedisCacheManager() {
        return redisCacheManager;
    }

    //@Bean 用在方法上，告诉Spring容器，可以从下面这个方法中拿到一个Bean
    @Bean
    public KeyGenerator customKeyGenerator() {
        return new KeyGenerator() {
            @Override
            //Object... objects意思是可以传递多个参数，参数的个数是不确定的，允许一切继承自Object的对象作为参数
            public Object generate(Object target, Method method, Object... objects) {
                StringBuilder sb = new StringBuilder();
                sb.append(target.getClass().getName());
                sb.append(method.getName());
                for (Object obj : objects) {
                    sb.append(obj.toString());
                }
                return sb.toString();
            }
        };
    }
}
