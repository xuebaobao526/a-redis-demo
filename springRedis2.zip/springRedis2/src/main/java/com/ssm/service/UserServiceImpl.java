package com.ssm.service;

import com.ssm.dao.UserMapper;
import com.ssm.pojo.User;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

@Service
@Transactional(propagation= Propagation.REQUIRED, rollbackFor=Exception.class)
public class UserServiceImpl implements IUserService{

    @Resource
    private UserMapper iUserDao;

    @Override
    /*通过Spring的@Cacheable来实现数据的缓存,主要针对方法配置，能够根据方法的请求参数对其结果进行缓存
      当调用这个方法的时候，会从指定的缓存(本质是一个map)中查询key为userId的值
      如果不存在，则执行实际的方法（即查询数据库等服务逻辑），并将执行的结果存入缓存中，否则返回缓存中的对象
     */
    @Cacheable("getUserById")
    public User getUserById(int userId) {
        return this.iUserDao.selectByPrimaryKey(userId);
    }

    @Override
    @Cacheable("getAllUser")
    public List<User> getAllUser() {
        return this.iUserDao.selectAllUser();
    }

    @Override
    /* 主要针对方法配置，能够根据一定的条件对缓存进行清空
       value字段指定缓存的名称
       allEntries字段确定是否清空所有缓存内容，缺省为 false，如果指定为 true，则方法调用后将立即清空所有缓存
    */
    @CacheEvict(value= {"getAllUser","getUserById","findUsers"},allEntries=true)
    public void insertUser(User user) {
        iUserDao.insertUser(user);
    }

    @CacheEvict(value= {"getAllUser","getUserById","findUsers"},allEntries=true)
    @Override
    public void deleteUser(int id) {
        this.iUserDao.deleteUser(id);
    }

    @Cacheable("findUsers")
    @Override
    public List<User> findUsers(String keyWords) {
        return iUserDao.findUsers(keyWords);
    }

    @CacheEvict(value= {"getAllUser","getUserById","findUsers"},allEntries=true)
    @Override
    public void editUser(User user) {
        this.iUserDao.editUser(user);
    }
}
