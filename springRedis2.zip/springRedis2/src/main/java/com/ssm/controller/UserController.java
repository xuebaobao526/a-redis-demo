package com.ssm.controller;

import com.ssm.pojo.User;
import com.ssm.service.IUserService;
import org.omg.CORBA.UserException;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

/**
 * @Author: lyx
 * @Date: 2018/7/6
 */
@Controller
public class UserController {

        @Resource
        private IUserService userService;

        @Resource
        private RedisTemplate redisTemplate;

    /**
         * 查询所有User
         *
         * @param request
         * @param model
         * @return
         */
        @RequestMapping(value = "/showUser", method = RequestMethod.GET)
        @ResponseBody
        public List<User> showUsers(Model model) {
            System.out.println("**********showUsers********");
            List<User> userList = new ArrayList<User>();
            userList = userService.getAllUser();

            //lyx 2108.7.6
            Iterator<User> ite = userList.iterator();
            while(ite.hasNext()){
                System.out.println(ite.next().toString());
            }

            return userList;
        }

    /**
     * 查询所有User
     *
     * @return
     */
    @RequestMapping(value = "/getUserById", method = RequestMethod.GET)
    @ResponseBody
    public User getUserById(Integer userId) {

        redisTemplate.opsForValue(); //返回一个默认的操作类
       // System.out.println(redisTemplate.boundValueOps("zhangsan").get()); //boundValueOps对象的get方法：获取key的所有的值
        User user = userService.getUserById(userId);
        return user;
    }

        /**
         * 增加一个用户
         *
         * @param userName
         * @param sex
         * @param age
         * @return
         */
        //将下面的方法声明为一个bean，当web请求为/addUser时，请求方法为post时，跳转到这个方法进行处理
        @RequestMapping(value = "/addUser", method = RequestMethod.POST)
        //在@RequestMapping后加上@ResponseBody，返回结果直接写入HTTP response body中，不会被解析为跳转路径
        @ResponseBody
        public ModelMap addUser(String userName, String sex, int age) {
            System.out.println("******addUser********");
            System.out.println(userName + sex + age);
            User user = new User();
            user.setSex(sex);
            user.setUserName(userName);
            user.setAge(age);
            userService.insertUser(user);
            ModelMap model = new ModelMap();
            model.addAttribute("result", "添加成功");
            return model;
        }

        /**
         * 通过userID删除用户
         *
         * @param userID
         */
        @RequestMapping(value = "/delUser/{userID}", method = RequestMethod.GET)
        //@PathVariable是用来获得请求url中的动态参数
        public ModelAndView delUser(@PathVariable int userID) {
            System.out.println(userID);
            userService.deleteUser(userID);
            //delete之后的userList（所有用户）
            ModelAndView mv = new ModelAndView();
            List<User> userList = new ArrayList<User>();
            userList = userService.getAllUser();
            mv.addObject("userList", userList); // 填充数据到model
            mv.setViewName("showUser");
            return mv;
        }

        /**
         * 查询用户
         *
         * @param model
         * @param keyWords
         * @return
         */
        @RequestMapping(value = "/search", method = RequestMethod.POST)
        public String findUsers(Model model, String keyWords) {
            System.out.println(keyWords);
            List<User> userList = new ArrayList<User>();
            userList = userService.findUsers(keyWords);
            model.addAttribute("userList", userList); // 填充数据到model
            return "showUser";
        }

        /**
         * 更新用户信息
         * @param userName
         * @param sex
         * @param age
         * @param id
         * @return
         */
        @RequestMapping(value="/editUser",method=RequestMethod.POST)
        public ModelAndView editUser(String userName, String sex, int age, int id) {
            System.out.println(userName + sex + age);
            User user = new User();
            user.setSex(sex);
            user.setUserName(userName);
            user.setAge(age);
            user.setId(id);
            userService.editUser(user);
            ModelAndView mv = new ModelAndView();
            List<User> userList = new ArrayList<User>();
            userList = userService.getAllUser();
            mv.addObject("userList", userList); // 填充数据到model
            mv.setViewName("redirect:/UserCRUD/showUser");
            return mv;
        }
}
